<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/datepicker3.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">
<link href="css/input.css" rel="stylesheet">

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<?php
include("header.php")

?>


</head>

<body>
<form action="academic_details.php" method="post">
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main" >			
		
		
		<div class="row" >
			<div class="col-lg-12">
				<h2 class="page-header" style="color:#1F618D  ;">Academic Details</h2>
			</div>

			</div>
			<div class="form-group">
									
									<table border="2px" style="width:100%;height:30%" >
									<tr><th>Sr.No</th><th>Examination</th><th>Year of Passing</th><th>marks(%)</th><th>Name of College</th><th>University/Board</th><th></th></tr>
									<tr><td contenteditable='true' bgcolor="#FFFFF"></td><td contenteditable='true' bgcolor="#FFFFF"><td contenteditable='true' bgcolor="#FFFFF"><td contenteditable='true' bgcolor="#FFFFF"><td contenteditable='true' bgcolor="#FFFFF"><td contenteditable='true' bgcolor="#FFFFF"></tr>
									<tr><td contenteditable='true' bgcolor="#FFFFF"></td><td contenteditable='true' bgcolor="#FFFFF"><td contenteditable='true' bgcolor="#FFFFF"><td contenteditable='true' bgcolor="#FFFFF"><td contenteditable='true' bgcolor="#FFFFF"><td contenteditable='true' bgcolor="#FFFFF"></tr>
									<tr><td contenteditable='true' bgcolor="#FFFFF"></td><td contenteditable='true' bgcolor="#FFFFF"><td contenteditable='true' bgcolor="#FFFFF"><td contenteditable='true' bgcolor="#FFFFF"><td contenteditable='true' bgcolor="#FFFFF"><td contenteditable='true' bgcolor="#FFFFF"></tr>
									</table>									
									
									<br><br>
									</div>	
								<div class="form-group">
								<button type="submit" name='form_submit' class="btn btn-primary" style="width:100px;">Ok</button>
							
								</div>		
				
			</form>
			
			
			</div>
								
			</div>